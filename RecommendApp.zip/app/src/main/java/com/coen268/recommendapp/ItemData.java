package com.coen268.recommendapp;


public class ItemData {
    public static final int TYPE_ORI = 0;
    public static final int TYPE_PIC = 1;
    public static final int TYPE_PRODUCT = 2;

    public ItemData(int sizeType, int jumpType, String url) {
        this.sizeType = sizeType;
        this.jumpType = jumpType;
        this.url = url;
    }

    public ItemData(int sizeType, int jumpType, String url, Float score) {
        this.sizeType = sizeType;
        this.jumpType = jumpType;
        this.url = url;
        this.score = score;
    }

    int sizeType;
    int jumpType;
    String url;

    public Float getScore() {
        return score;
    }

    Float score;

    public String getUrl() {
        return url;
    }

    public int getSizeType() {
        return sizeType;
    }

    public int getJumpType() {
        return jumpType;
    }
}
