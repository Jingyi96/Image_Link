package com.coen268.recommendapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    public final static String EMAIL = "w";
    public final static String PASSWORD = "w";

    EditText email;
    EditText password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.et_email);
        password = findViewById(R.id.et_password);

    }

    public void login(View view){

        String userText = email.getText().toString();
        String passText = password.getText().toString();

        Intent intent = new Intent(this, PicActivity.class);

        if (userText.compareTo(EMAIL) == 0 && passText.compareTo(PASSWORD) == 0){
            startActivity(intent);
        }
        else{
            CharSequence text = "Email Account or Password is Incorrect.";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(this, text, duration);
            toast.show();
        }
    }
}